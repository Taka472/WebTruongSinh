// const sqlConfig = {
//     user: 'TranLeHuy',
//     password: 'tranlehuy',
//     database: 'WebTruongSinh',
//     server: 'localhost',
//     trustServerCertificate: true,
//     pool: {
//         max: 10,
//         min: 0,
//         idleTimeoutMillis: 1000
//     },
//     option: {
//         encrypt: true,
        
//     }
// }

// module.exports = sqlConfig;

const mysql = require('mysql2')

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '123456',
    database: 'webtruongsinh'
})

module.exports = connection